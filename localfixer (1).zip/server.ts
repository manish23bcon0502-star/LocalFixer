import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import { createServer as createViteServer } from "vite";
import path from "path";
import fs from "fs";
import cors from "cors";

const PORT = 3000;
const DB_FILE = path.join(process.cwd(), "db.json");

// Initialize DB if not exists
if (!fs.existsSync(DB_FILE)) {
  fs.writeFileSync(DB_FILE, JSON.stringify({
    users: [],
    workers: [
      { id: "w1", name: "Rajesh Kumar", skill: "Carpenter", rating: 4.8, price: 500, location: { lat: 26.9124, lng: 75.7873 }, bio: "Expert in furniture repair and custom woodwork.", verified: true },
      { id: "w2", name: "Sunil Sharma", skill: "Painter", rating: 4.5, price: 300, location: { lat: 26.8500, lng: 75.8000 }, bio: "Professional house painting and wall textures.", verified: true },
      { id: "w3", name: "Amit Singh", skill: "Electrician", rating: 4.9, price: 400, location: { lat: 26.9000, lng: 75.7500 }, bio: "Certified electrician for home wiring and repairs.", verified: false },
      { id: "w4", name: "Vijay Mali", skill: "Gardener", rating: 4.7, price: 250, location: { lat: 26.9500, lng: 75.8500 }, bio: "Landscaping and garden maintenance specialist.", verified: true }
    ],
    messages: [],
    bookings: []
  }, null, 2));
}

async function startServer() {
  const app = express();
  const httpServer = createServer(app);
  const io = new Server(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });

  app.use(cors());
  app.use(express.json());

  // API Routes
  app.get("/api/workers", (req, res) => {
    const db = JSON.parse(fs.readFileSync(DB_FILE, "utf-8"));
    res.json(db.workers);
  });

  app.get("/api/messages/:userId/:workerId", (req, res) => {
    const { userId, workerId } = req.params;
    const db = JSON.parse(fs.readFileSync(DB_FILE, "utf-8"));
    const chatMessages = db.messages.filter((m: any) => 
      (m.from === userId && m.to === workerId) || (m.from === workerId && m.to === userId)
    );
    res.json(chatMessages);
  });

  app.post("/api/bookings", (req, res) => {
    const booking = req.body;
    const db = JSON.parse(fs.readFileSync(DB_FILE, "utf-8"));
    booking.id = "b" + Date.now();
    db.bookings.push(booking);
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
    res.json(booking);
  });

  // Socket.io logic
  io.on("connection", (socket) => {
    console.log("User connected:", socket.id);

    socket.on("join", (room) => {
      socket.join(room);
      console.log(`User joined room: ${room}`);
    });

    socket.on("send_message", (data) => {
      const db = JSON.parse(fs.readFileSync(DB_FILE, "utf-8"));
      const newMessage = {
        ...data,
        id: "m" + Date.now(),
        timestamp: new Date().toISOString()
      };
      db.messages.push(newMessage);
      fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
      
      const room = [data.from, data.to].sort().join("-");
      io.to(room).emit("receive_message", newMessage);
    });

    socket.on("disconnect", () => {
      console.log("User disconnected");
    });
  });

  // Vite middleware
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
