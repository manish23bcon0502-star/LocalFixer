import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { useState, useEffect } from "react";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import Search from "./pages/Search";
import WorkerProfile from "./pages/WorkerProfile";
import Login from "./pages/Login";
import Chat from "./components/Chat";
import FixerAI from "./components/FixerAI";
import { motion, AnimatePresence } from "motion/react";

export default function App() {
  const [user, setUser] = useState<{ id: string; name: string; role: 'customer' | 'worker' } | null>(null);
  const [activeChat, setActiveChat] = useState<{ id: string; name: string } | null>(null);
  const [showFixerAI, setShowFixerAI] = useState(false);

  useEffect(() => {
    const savedUser = localStorage.getItem("user");
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
  }, []);

  const handleLogin = (userData: any) => {
    setUser(userData);
    localStorage.setItem("user", JSON.stringify(userData));
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem("user");
  };

  return (
    <Router>
      <div className="min-h-screen bg-slate-50 font-sans text-slate-900">
        <Navbar user={user} onLogout={handleLogout} onOpenAI={() => setShowFixerAI(true)} />
        
        <main className="container mx-auto px-4 py-8">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/search" element={<Search onChat={setActiveChat} />} />
            <Route path="/worker/:id" element={<WorkerProfile onChat={setActiveChat} />} />
            <Route path="/login" element={<Login onLogin={handleLogin} />} />
          </Routes>
        </main>

        <AnimatePresence>
          {activeChat && user && (
            <Chat 
              user={user} 
              target={activeChat} 
              onClose={() => setActiveChat(null)} 
            />
          )}
          {showFixerAI && (
            <FixerAI onClose={() => setShowFixerAI(false)} />
          )}
        </AnimatePresence>

        {/* Floating AI Button */}
        {!showFixerAI && (
          <motion.button
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => setShowFixerAI(true)}
            className="fixed bottom-8 right-8 bg-indigo-600 text-white p-4 rounded-full shadow-lg z-40 flex items-center gap-2"
          >
            <span className="font-medium">FixerAI</span>
          </motion.button>
        )}
      </div>
    </Router>
  );
}
