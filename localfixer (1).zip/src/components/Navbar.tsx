import { Link } from "react-router-dom";
import { Search, User, MessageSquare, LogOut, Sparkles } from "lucide-react";

interface NavbarProps {
  user: { id: string; name: string; role: 'customer' | 'worker' } | null;
  onLogout: () => void;
  onOpenAI: () => void;
}

export default function Navbar({ user, onLogout, onOpenAI }: NavbarProps) {
  return (
    <nav className="bg-white border-b border-slate-200 sticky top-0 z-50">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link to="/" className="text-2xl font-bold text-indigo-600 flex items-center gap-2">
          <Sparkles className="w-8 h-8" />
          <span>Localfixer</span>
        </Link>

        <div className="flex items-center gap-6">
          <Link to="/search" className="text-slate-600 hover:text-indigo-600 flex items-center gap-1">
            <Search className="w-5 h-5" />
            <span className="hidden sm:inline">Find Services</span>
          </Link>

          {user ? (
            <div className="flex items-center gap-4">
              <span className="text-slate-600 hidden md:inline">Hi, {user.name}</span>
              <button 
                onClick={onLogout}
                className="text-slate-600 hover:text-red-600 flex items-center gap-1"
              >
                <LogOut className="w-5 h-5" />
                <span className="hidden sm:inline">Logout</span>
              </button>
            </div>
          ) : (
            <Link to="/login" className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition-colors flex items-center gap-2">
              <User className="w-5 h-5" />
              <span>Login</span>
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
}
