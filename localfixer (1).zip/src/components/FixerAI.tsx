import React, { useState, useRef, useEffect } from "react";
import { GoogleGenAI } from "@google/genai";
import { Sparkles, X, Send, Bot, User, Loader2, IndianRupee, Hammer } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

interface Message {
  role: "user" | "ai";
  text: string;
  type?: "estimate" | "recommendation";
  data?: any;
}

export default function FixerAI({ onClose }: { onClose: () => void }) {
  const [messages, setMessages] = useState<Message[]>([
    { role: "ai", text: "Hi! I'm FixerAI. Tell me what's broken, and I'll estimate the cost and find the best local experts for you." }
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    const userText = input;
    setInput("");
    setMessages(prev => [...prev, { role: "user", text: userText }]);
    setLoading(true);

    try {
      const model = genAI.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `
          You are FixerAI, a smart assistant for a home service marketplace called Localfixer.
          The user is describing a problem: "${userText}".
          
          Based on this, provide:
          1. A realistic price range for the repair in Indian Rupees (INR).
          2. A brief explanation of what needs to be done.
          3. The type of worker needed (Carpenter, Painter, Electrician, or Gardener).
          
          Format your response as a JSON object:
          {
            "estimate": "₹500 - ₹1200",
            "explanation": "Brief explanation here...",
            "workerType": "Electrician",
            "message": "Friendly response message here..."
          }
        `,
        config: { responseMimeType: "application/json" }
      });

      const result = await model;
      const data = JSON.parse(result.text || "{}");
      
      setMessages(prev => [...prev, { 
        role: "ai", 
        text: data.message,
        type: "estimate",
        data: data
      }]);

      // Fetch matching workers
      const workersRes = await fetch("/api/workers");
      const workers = await workersRes.json();
      const matchedWorkers = workers.filter((w: any) => w.skill === data.workerType);

      if (matchedWorkers.length > 0) {
        setMessages(prev => [...prev, {
          role: "ai",
          text: `I found ${matchedWorkers.length} ${data.workerType}s near you who can help:`,
          type: "recommendation",
          data: matchedWorkers
        }]);
      }

    } catch (error) {
      console.error("AI Error:", error);
      setMessages(prev => [...prev, { role: "ai", text: "Sorry, I'm having trouble connecting right now. Please try again later." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div
      initial={{ x: 400, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      exit={{ x: 400, opacity: 0 }}
      className="fixed inset-y-0 right-0 w-full md:w-[450px] bg-white shadow-2xl z-50 flex flex-col border-l border-slate-100"
    >
      {/* Header */}
      <div className="bg-gradient-to-r from-indigo-600 to-violet-700 p-6 flex items-center justify-between text-white">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center backdrop-blur-md">
            <Sparkles className="w-7 h-7" />
          </div>
          <div>
            <h3 className="text-xl font-bold">FixerAI Assistant</h3>
            <p className="text-xs text-indigo-100">AI-Powered Estimates & Matching</p>
          </div>
        </div>
        <button onClick={onClose} className="p-2 hover:bg-white/20 rounded-full transition-colors">
          <X className="w-6 h-6" />
        </button>
      </div>

      {/* Chat Area */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-50">
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
            <div className={`flex gap-3 max-w-[90%] ${msg.role === "user" ? "flex-row-reverse" : "flex-row"}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                msg.role === "user" ? "bg-indigo-600 text-white" : "bg-white text-indigo-600 shadow-sm border border-slate-100"
              }`}>
                {msg.role === "user" ? <User className="w-5 h-5" /> : <Bot className="w-5 h-5" />}
              </div>
              
              <div className="space-y-3">
                <div className={`p-4 rounded-2xl text-sm leading-relaxed ${
                  msg.role === "user" 
                    ? "bg-indigo-600 text-white rounded-tr-none" 
                    : "bg-white text-slate-700 border border-slate-100 rounded-tl-none shadow-sm"
                }`}>
                  {msg.text}
                </div>

                {msg.type === "estimate" && msg.data && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-emerald-50 border border-emerald-100 p-4 rounded-2xl"
                  >
                    <div className="flex items-center gap-2 text-emerald-700 font-bold mb-2">
                      <IndianRupee className="w-5 h-5" />
                      <span>Estimated Cost</span>
                    </div>
                    <p className="text-2xl font-black text-emerald-800 mb-2">{msg.data.estimate}</p>
                    <p className="text-xs text-emerald-600">{msg.data.explanation}</p>
                  </motion.div>
                )}

                {msg.type === "recommendation" && msg.data && (
                  <div className="space-y-3">
                    {msg.data.map((worker: any) => (
                      <motion.div 
                        key={worker.id}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        className="bg-white p-3 rounded-xl border border-slate-100 shadow-sm flex items-center justify-between gap-3"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-indigo-50 rounded-lg flex items-center justify-center text-indigo-600 font-bold">
                            {worker.name[0]}
                          </div>
                          <div>
                            <p className="text-sm font-bold">{worker.name}</p>
                            <p className="text-[10px] text-slate-500">₹{worker.price}/hr • {worker.rating} ★</p>
                          </div>
                        </div>
                        <button className="text-xs bg-indigo-600 text-white px-3 py-1.5 rounded-lg font-bold">
                          Hire
                        </button>
                      </motion.div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex items-center gap-2">
              <Loader2 className="w-5 h-5 animate-spin text-indigo-600" />
              <span className="text-sm text-slate-500">FixerAI is thinking...</span>
            </div>
          </div>
        )}
        <div ref={scrollRef} />
      </div>

      {/* Input Area */}
      <form onSubmit={handleSend} className="p-6 bg-white border-t border-slate-100 flex gap-3">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Describe your problem (e.g. leaking tap)..."
          className="flex-1 px-5 py-3 rounded-2xl bg-slate-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 text-sm"
        />
        <button
          type="submit"
          disabled={loading}
          className="p-3 bg-indigo-600 text-white rounded-2xl hover:bg-indigo-700 transition-colors disabled:opacity-50"
        >
          <Send className="w-6 h-6" />
        </button>
      </form>
    </motion.div>
  );
}
