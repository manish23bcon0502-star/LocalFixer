import { Link } from "react-router-dom";
import { motion } from "motion/react";
import { Hammer, Paintbrush, Zap, Sprout, ShieldCheck, Clock, MapPin } from "lucide-react";

const services = [
  { name: "Carpentry", icon: Hammer, color: "bg-amber-100 text-amber-600" },
  { name: "Painting", icon: Paintbrush, color: "bg-rose-100 text-rose-600" },
  { name: "Electrical", icon: Zap, color: "bg-blue-100 text-blue-600" },
  { name: "Gardening", icon: Sprout, color: "bg-emerald-100 text-emerald-600" }
];

export default function Home() {
  return (
    <div className="space-y-24">
      {/* Hero Section */}
      <section className="relative h-[600px] flex items-center justify-center overflow-hidden rounded-3xl">
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-600 to-violet-700 z-0" />
        <div className="absolute inset-0 opacity-20 bg-[url('https://picsum.photos/seed/home/1920/1080')] bg-cover bg-center mix-blend-overlay" />
        
        <div className="relative z-10 text-center text-white px-4 max-w-4xl">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl md:text-7xl font-bold mb-6 tracking-tight"
          >
            Reliable Home Services, <br />
            <span className="text-indigo-200">Just a Click Away.</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-xl md:text-2xl text-indigo-50 mb-10 font-light"
          >
            Connect with verified local experts for all your home maintenance needs.
          </motion.p>
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <Link to="/search" className="bg-white text-indigo-600 px-8 py-4 rounded-xl font-bold text-lg hover:bg-indigo-50 transition-all shadow-xl">
              Find a Worker
            </Link>
            <Link to="/login" className="bg-indigo-500/30 backdrop-blur-md border border-white/30 text-white px-8 py-4 rounded-xl font-bold text-lg hover:bg-white/20 transition-all">
              Join as Worker
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Services Grid */}
      <section>
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold mb-4">What do you need help with?</h2>
          <p className="text-slate-600">Choose from our wide range of professional services</p>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, idx) => (
            <motion.div
              key={service.name}
              whileHover={{ y: -5 }}
              className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm text-center group cursor-pointer"
            >
              <div className={`w-16 h-16 ${service.color} rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform`}>
                <service.icon className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold">{service.name}</h3>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Trust Features */}
      <section className="bg-slate-900 text-white py-20 rounded-3xl px-8">
        <div className="grid md:grid-cols-3 gap-12 max-w-6xl mx-auto">
          <div className="flex flex-col items-center text-center">
            <div className="bg-indigo-500/20 p-4 rounded-full mb-6">
              <ShieldCheck className="w-10 h-10 text-indigo-400" />
            </div>
            <h3 className="text-2xl font-bold mb-3">Verified Experts</h3>
            <p className="text-slate-400">Every worker undergoes a strict identity and skill verification process.</p>
          </div>
          <div className="flex flex-col items-center text-center">
            <div className="bg-indigo-500/20 p-4 rounded-full mb-6">
              <Clock className="w-10 h-10 text-indigo-400" />
            </div>
            <h3 className="text-2xl font-bold mb-3">Quick Response</h3>
            <p className="text-slate-400">Get connected with available workers in your area within minutes.</p>
          </div>
          <div className="flex flex-col items-center text-center">
            <div className="bg-indigo-500/20 p-4 rounded-full mb-6">
              <MapPin className="w-10 h-10 text-indigo-400" />
            </div>
            <h3 className="text-2xl font-bold mb-3">Local First</h3>
            <p className="text-slate-400">Support your local community by hiring skilled workers from your neighborhood.</p>
          </div>
        </div>
      </section>
    </div>
  );
}
