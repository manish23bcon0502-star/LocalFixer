import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Star, ShieldCheck, MapPin, MessageSquare, Calendar, ArrowLeft, CheckCircle2 } from "lucide-react";
import { motion } from "motion/react";

interface Worker {
  id: string;
  name: string;
  skill: string;
  rating: number;
  price: number;
  location: { lat: number; lng: number };
  bio: string;
  verified: boolean;
}

interface WorkerProfileProps {
  onChat: (worker: { id: string; name: string }) => void;
}

export default function WorkerProfile({ onChat }: WorkerProfileProps) {
  const { id } = useParams();
  const navigate = useNavigate();
  const [worker, setWorker] = useState<Worker | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/workers")
      .then(res => res.json())
      .then(data => {
        const found = data.find((w: any) => w.id === id);
        setWorker(found || null);
        setLoading(false);
      });
  }, [id]);

  if (loading) return <div className="text-center py-20">Loading profile...</div>;
  if (!worker) return <div className="text-center py-20">Worker not found.</div>;

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      <button 
        onClick={() => navigate(-1)}
        className="flex items-center gap-2 text-slate-500 hover:text-indigo-600 font-medium transition-colors"
      >
        <ArrowLeft className="w-5 h-5" />
        Back to search
      </button>

      <div className="grid md:grid-cols-3 gap-8">
        {/* Left Column: Profile Info */}
        <div className="md:col-span-2 space-y-8">
          <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
            <div className="flex flex-col sm:flex-row gap-6 items-start sm:items-center mb-8">
              <div className="w-24 h-24 bg-indigo-100 rounded-3xl flex items-center justify-center text-indigo-600 font-bold text-4xl">
                {worker.name[0]}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <h1 className="text-3xl font-bold">{worker.name}</h1>
                  {worker.verified && <ShieldCheck className="w-6 h-6 text-emerald-500" />}
                </div>
                <p className="text-slate-500 text-lg mb-3">{worker.skill}</p>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-1 text-amber-500 font-bold">
                    <Star className="w-5 h-5 fill-current" />
                    {worker.rating}
                  </div>
                  <div className="flex items-center gap-1 text-slate-400">
                    <MapPin className="w-5 h-5" />
                    <span>Jaipur, Rajasthan</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <div>
                <h3 className="text-xl font-bold mb-3">About Me</h3>
                <p className="text-slate-600 leading-relaxed">{worker.bio}</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
                  <p className="text-slate-500 text-sm mb-1">Hourly Rate</p>
                  <p className="text-2xl font-bold text-indigo-600">₹{worker.price}</p>
                </div>
                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100">
                  <p className="text-slate-500 text-sm mb-1">Experience</p>
                  <p className="text-2xl font-bold text-slate-700">5+ Years</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
            <h3 className="text-xl font-bold mb-6">Skills & Expertise</h3>
            <div className="flex flex-wrap gap-3">
              {["Furniture Repair", "Custom Woodwork", "Door Fixing", "Cabinet Installation", "Polishing"].map(skill => (
                <span key={skill} className="bg-indigo-50 text-indigo-600 px-4 py-2 rounded-xl text-sm font-medium border border-indigo-100">
                  {skill}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Booking Card */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-3xl shadow-xl border border-slate-100 sticky top-24">
            <h3 className="text-xl font-bold mb-6">Book Service</h3>
            
            <div className="space-y-4 mb-8">
              <div className="flex items-center gap-3 text-slate-600">
                <Calendar className="w-5 h-5" />
                <span>Next Available: Tomorrow</span>
              </div>
              <div className="flex items-center gap-3 text-slate-600">
                <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                <span>Verified Identity</span>
              </div>
            </div>

            <div className="space-y-3">
              <button 
                onClick={() => onChat({ id: worker.id, name: worker.name })}
                className="w-full bg-slate-100 text-slate-700 py-4 rounded-xl font-bold hover:bg-slate-200 transition-all flex items-center justify-center gap-2"
              >
                <MessageSquare className="w-5 h-5" />
                Chat with {worker.name.split(" ")[0]}
              </button>
              <button className="w-full bg-indigo-600 text-white py-4 rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg hover:shadow-indigo-200">
                Book Now
              </button>
            </div>

            <p className="text-center text-xs text-slate-400 mt-6">
              Funds will be held securely until the job is completed.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
