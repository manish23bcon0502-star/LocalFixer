import { useState, useEffect } from "react";
import { Search as SearchIcon, MapPin, Star, ShieldCheck, MessageSquare } from "lucide-react";
import { motion } from "motion/react";

interface Worker {
  id: string;
  name: string;
  skill: string;
  rating: number;
  price: number;
  location: { lat: number; lng: number };
  bio: string;
  verified: boolean;
}

interface SearchProps {
  onChat: (worker: { id: string; name: string }) => void;
}

export default function Search({ onChat }: SearchProps) {
  const [workers, setWorkers] = useState<Worker[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedSkill, setSelectedSkill] = useState("All");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/workers")
      .then(res => res.json())
      .then(data => {
        setWorkers(data);
        setLoading(false);
      });
  }, []);

  const filteredWorkers = workers.filter(w => {
    const matchesSearch = w.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         w.skill.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesSkill = selectedSkill === "All" || w.skill === selectedSkill;
    return matchesSearch && matchesSkill;
  });

  const skills = ["All", "Carpenter", "Painter", "Electrician", "Gardener"];

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
        <h1 className="text-3xl font-bold">Find Local Experts</h1>
        <div className="relative w-full md:w-96">
          <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Search by name or skill..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white"
          />
        </div>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
        {skills.map(skill => (
          <button
            key={skill}
            onClick={() => setSelectedSkill(skill)}
            className={`px-6 py-2 rounded-full font-medium transition-all whitespace-nowrap ${
              selectedSkill === skill 
                ? "bg-indigo-600 text-white shadow-md" 
                : "bg-white text-slate-600 border border-slate-200 hover:border-indigo-300"
            }`}
          >
            {skill}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-64 bg-slate-200 animate-pulse rounded-2xl" />
          ))}
        </div>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredWorkers.map(worker => (
            <motion.div
              layout
              key={worker.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex justify-between items-start mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-600 font-bold text-xl">
                    {worker.name[0]}
                  </div>
                  <div>
                    <h3 className="font-bold text-lg flex items-center gap-1">
                      {worker.name}
                      {worker.verified && <ShieldCheck className="w-4 h-4 text-emerald-500" />}
                    </h3>
                    <p className="text-slate-500 text-sm">{worker.skill}</p>
                  </div>
                </div>
                <div className="flex items-center gap-1 text-amber-500 font-bold">
                  <Star className="w-4 h-4 fill-current" />
                  {worker.rating}
                </div>
              </div>

              <p className="text-slate-600 text-sm mb-6 line-clamp-2">
                {worker.bio}
              </p>

              <div className="flex items-center justify-between">
                <div>
                  <span className="text-2xl font-bold text-indigo-600">₹{worker.price}</span>
                  <span className="text-slate-400 text-sm">/hr</span>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={() => onChat({ id: worker.id, name: worker.name })}
                    className="p-3 bg-slate-100 text-slate-600 rounded-xl hover:bg-slate-200 transition-colors"
                  >
                    <MessageSquare className="w-5 h-5" />
                  </button>
                  <button className="bg-indigo-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-indigo-700 transition-colors">
                    Hire Now
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {!loading && filteredWorkers.length === 0 && (
        <div className="text-center py-20">
          <p className="text-slate-500 text-lg">No workers found matching your criteria.</p>
        </div>
      )}
    </div>
  );
}
